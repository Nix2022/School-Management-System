<div class="page-content-wrapper">
    <div class="page-content">
        <!-- BEGIN PAGE CONTENT-->
        <div class="row">
            <div class="col-md-12">
                <div class="alert alert-success submitSuccessMessage">
                    <h1><?php echo lang('exa_rss'); ?> </h1><hr>
                    <strong><?php echo lang('success'); ?></strong> <?php echo $this->common->class_title($class_id) . ', ' . $examTitle . ' and subject " ' . $examSubject . ' "'; ?> <?php echo lang('exa_erwsb'); ?> <?php echo $teacherName; ?>.
                    <hr>
                    <h3>Thank You</h3>
                </div>
            </div>
        </div>
        <!-- END PAGE CONTENT-->
    </div>
</div>