<!-- BEGIN CONTENT -->
<div class="page-content-wrapper">
    <div class="page-content">
        <!-- BEGIN PAGE CONTENT-->
        <div class="row">
            <div class="col-md-12 ">
                <div class="alert alert-danger">
                    <h3><?php echo lang('exa_today_a').$classTitle.lang('exa_today_b'); ?></h3><hr>
                    <strong><?php echo lang('exa_today_c'); ?></strong><hr>
                    <div class="clearfix">
                        <button class="btn blue btn-lg" type="button" onclick="location.href = 'javascript:history.back();'"><?php echo lang('back'); ?></button>
                    </div>
                </div>
            </div>
        </div>
        <!-- END PAGE CONTENT-->
    </div>
</div>
<!-- END CONTENT -->

